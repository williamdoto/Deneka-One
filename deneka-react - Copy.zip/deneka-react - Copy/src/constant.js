export const AVATAR_API = "https://ui-avatars.com/api";
export const API = "http://localhost:1337/api";
export const AUTH_TOKEN = "authToken";
export const BEARER = "Bearer";